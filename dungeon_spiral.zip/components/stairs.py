class Stairs:
	def __init__(self, target_floor):
		self.target_floor = target_floor